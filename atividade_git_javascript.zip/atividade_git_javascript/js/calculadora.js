// Calculadora com as quatro operações básicas.
const campo1 = document.querySelector("#numero1");
const campo2 = document.querySelector("#numero2");
const operacao = document.querySelector("#operacao");
const botaoCalcular = document.querySelector("#calcular");
const resultado = document.querySelector("#resultado");

botaoCalcular.addEventListener("click", () => {
  const n1 = Number(campo1.value);
  const n2 = Number(campo2.value);

  if (campo1.value.trim() === "" || campo2.value.trim() === "") {
    resultado.textContent = "Preencha os dois números.";
    return;
  }

  let total;
  switch (operacao.value) {
    case "+": total = n1 + n2; break;
    case "-": total = n1 - n2; break;
    case "*": total = n1 * n2; break;
    case "/":
      if (n2 === 0) {
        resultado.textContent = "Não é possível dividir por zero.";
        return;
      }
      total = n1 / n2;
      break;
  }

  resultado.textContent = `Resultado: ${total}`;
});
