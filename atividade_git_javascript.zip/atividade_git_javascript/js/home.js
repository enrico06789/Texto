// Exibe a data atual na página inicial.
const elementoData = document.querySelector("#mensagem-data");

if (elementoData) {
  const hoje = new Date();
  elementoData.textContent = `Hoje é ${hoje.toLocaleDateString("pt-BR")}. Bons estudos!`;
}
