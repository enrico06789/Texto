// Lista de tarefas. Os dados ficam salvos no navegador.
const formulario = document.querySelector("#form-tarefa");
const campoTarefa = document.querySelector("#nova-tarefa");
const lista = document.querySelector("#lista-tarefas");
const aviso = document.querySelector("#aviso");

let tarefas = JSON.parse(localStorage.getItem("tarefas-js")) || [];

function salvarTarefas() {
  localStorage.setItem("tarefas-js", JSON.stringify(tarefas));
}

function desenharTarefas() {
  lista.innerHTML = "";

  if (tarefas.length === 0) {
    aviso.textContent = "Nenhuma tarefa cadastrada.";
    return;
  }

  aviso.textContent = "";
  tarefas.forEach((tarefa, indice) => {
    const item = document.createElement("li");
    const texto = document.createElement("span");
    texto.textContent = tarefa;

    const remover = document.createElement("button");
    remover.textContent = "Excluir";
    remover.className = "botao excluir";
    remover.type = "button";
    remover.addEventListener("click", () => {
      tarefas.splice(indice, 1);
      salvarTarefas();
      desenharTarefas();
    });

    item.append(texto, remover);
    lista.appendChild(item);
  });
}

formulario.addEventListener("submit", evento => {
  evento.preventDefault();
  const texto = campoTarefa.value.trim();

  if (texto === "") return;

  tarefas.push(texto);
  salvarTarefas();
  desenharTarefas();
  campoTarefa.value = "";
  campoTarefa.focus();
});

desenharTarefas();
