// Quiz simples sobre conceitos básicos de programação.
const perguntas = [
  {
    texto: "Qual comando mostra uma mensagem no console do JavaScript?",
    opcoes: ["print()", "console.log()", "echo()", "writeLine()"],
    correta: 1
  },
  {
    texto: "Qual palavra pode declarar uma variável que pode receber outro valor?",
    opcoes: ["const", "fixed", "let", "static"],
    correta: 2
  },
  {
    texto: "Qual símbolo é usado para comentários de uma linha em JavaScript?",
    opcoes: ["//", "<!-- -->", "**", "##"],
    correta: 0
  }
];

let indice = 0;
let pontos = 0;

const pergunta = document.querySelector("#pergunta");
const alternativas = document.querySelector("#alternativas");
const feedback = document.querySelector("#feedback");
const pontuacao = document.querySelector("#pontuacao");
const proxima = document.querySelector("#proxima");
const reiniciar = document.querySelector("#reiniciar");

function mostrarPergunta() {
  const atual = perguntas[indice];
  pergunta.textContent = atual.texto;
  alternativas.innerHTML = "";
  feedback.textContent = "";
  proxima.hidden = true;

  atual.opcoes.forEach((opcao, numero) => {
    const botao = document.createElement("button");
    botao.className = "botao opcao";
    botao.textContent = opcao;
    botao.addEventListener("click", () => responder(numero));
    alternativas.appendChild(botao);
  });
}

function responder(escolha) {
  const correta = perguntas[indice].correta;
  document.querySelectorAll(".opcao").forEach(botao => botao.disabled = true);

  if (escolha === correta) {
    pontos++;
    feedback.textContent = "Correto! Muito bem.";
  } else {
    feedback.textContent = `Não foi dessa vez. Resposta correta: ${perguntas[indice].opcoes[correta]}.`;
  }

  pontuacao.textContent = `Pontuação: ${pontos} de ${perguntas.length}`;
  if (indice < perguntas.length - 1) {
    proxima.hidden = false;
  } else {
    pergunta.textContent = "Quiz finalizado!";
    reiniciar.hidden = false;
  }
}

proxima.addEventListener("click", () => {
  indice++;
  mostrarPergunta();
});

reiniciar.addEventListener("click", () => {
  indice = 0;
  pontos = 0;
  pontuacao.textContent = "Pontuação: 0";
  reiniciar.hidden = true;
  mostrarPergunta();
});

mostrarPergunta();
