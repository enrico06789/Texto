# Atividade prática — Git e GitHub com JavaScript

Projeto demonstrativo com três aplicações feitas em JavaScript e executadas no navegador.

## Como executar
1. Extraia a pasta do projeto.
2. Abra a pasta no Visual Studio Code.
3. Abra o arquivo `index.html` no navegador. Se tiver a extensão Live Server, clique com o botão direito no arquivo e escolha **Open with Live Server**.

## Páginas
- `index.html`: página inicial e data atual.
- `calculadora.html`: soma, subtração, multiplicação e divisão.
- `quiz.html`: perguntas de múltipla escolha e pontuação.
- `tarefas.html`: cadastro e exclusão de tarefas, com salvamento no navegador.

## Estrutura
- `js/`: códigos JavaScript.
- `css/`: estilos visuais.
- Arquivos `.html`: páginas que carregam os respectivos arquivos JavaScript.

## Sugestão de apresentação
Demonstre cada página no navegador e mostre os arquivos `.js` no VS Code. Para evidenciar o versionamento, faça alterações pequenas e crie commits com mensagens claras, por exemplo:
- `Adiciona estrutura inicial do projeto`
- `Cria calculadora em JavaScript`
- `Adiciona quiz interativo`
- `Implementa lista de tarefas`

## Git — comandos úteis
Execute no terminal integrado do VS Code, dentro da pasta do projeto:

```bash
git init
git add .
git commit -m "Adiciona estrutura inicial do projeto"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/SEU-REPOSITORIO.git
git push -u origin main
```

Troque a URL de exemplo pelo endereço do repositório criado na sua conta do GitHub.
